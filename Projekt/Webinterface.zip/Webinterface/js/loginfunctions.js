function loginButtonClicked(){
	
}




function functionRegister(){
		//$.notify("Eine Registrierungsanfrage wird an den Administrator gesendet", "info");	

}



function functionLogout(){
	$.notify("Sie werden nun abgemeldet", "info");
}



